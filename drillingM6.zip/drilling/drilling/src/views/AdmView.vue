<template>
  <div class="adm">
    <h1>Para ver la informacion ingresa tus datos</h1>
    <b-button variant="success" @click="IngresoCuenta">Ingresar Datos</b-button>
  </div>
</template>
<script>
  import Vue from "vue";
export default Vue.extend({
  name: "AdmView",
  methods: {
    IngresoCuenta() {
      const nombre= prompt("Ingrese su nombre")
      const apellido= prompt("Ingrese su apellido");
      if (nombre && apellido) {
        this.$router.push('/account')
      }
    }
  },
});
</script>
