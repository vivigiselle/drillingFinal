<template>
  <div>
    <h1 class="d-flex justify-content-center" style="margin: 30px;">Lista de Juegos Disponibles</h1>
    <div class="container row" v-if="games.length > 0">
      <div v-for="game in games" 
      :key="game.id" 
      class="col-md-4">
        <CardComponent :gameProps = "game"/>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import axios from "axios";
import CardComponent from "@/components/CardComponent.vue";
export default Vue.extend({
  name: "HomeView",
  components: {
    CardComponent,
  },
  data() {
    return {
      games: [],
    };
  },
  methods: {
    getAllInfo() {
      axios
        .get(
          `${process.env.VUE_APP_URL}games?key=${process.env.VUE_APP_KEY_RAWG}`
        )
        .then((response) => {
          this.games = response.data.results;
        })
        .catch((error)=>{
          console.log(error)
        })
    },
  },
  created() {
    this.getAllInfo();
  },
});
</script>
