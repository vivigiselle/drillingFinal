<template>
  <div>
    <h2>Resumen de tu cuenta</h2>
    <br />
    <h3>Le diste me gusta al juego</h3>  <!--Buscar mas formas de hacer la ruta dinamica. Que me envie a otra vista y se guarde la info a cual juego le di like-->
    <div class="container" style="width: 500px">
      <b-card-group deck>
        <b-card footer-tag="footer">
          <b-card-text>¿Deseas comprar coins para este juego?</b-card-text>
          <b-button href="#" variant="warning" @click="NotFound">Agregar Coins</b-button> <!--Solo para guardar el 404 del drilling-->
          <template #footer>
            <h5>Cantidad de coins comprados</h5>
          </template>
        </b-card>
      </b-card-group>
    </div>
    <div class="loader"></div>
  </div>
</template>

<script>
import Vue from "vue";
export default Vue.extend({
  name: "AccountView",
  methods: {
    NotFound() {
      this.$router.push({
        name: "error"
      });
    },
},
});
</script>

<style scoped>
.loader {
  transform: translateZ(1px);
}

.loader:after {
  content: "$";
  display: inline-block;
  margin: 20px;
  width: 45px;
  height: 45px;
  border-radius: 50%;
  text-align: center;
  line-height: 40px;
  font-size: 32px;
  font-weight: bold;
  background: #ffd700;
  color: #daa520;
  border: 4px double;
  box-sizing: border-box;
  box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.1);
  animation: coin-flip 4s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}

@keyframes coin-flip {
  0%,
  100% {
    animation-timing-function: cubic-bezier(0.5, 0, 1, 0.5);
  }

  0% {
    transform: rotateY(0deg);
  }

  50% {
    transform: rotateY(1800deg);
    animation-timing-function: cubic-bezier(0, 0.5, 0.5, 1);
  }

  100% {
    transform: rotateY(3600deg);
  }
}
</style>
