<template>
  <form>
    <div class="space-y-12">
      <div class="border-b border-gray-900/10 pb-12">
        <h2 class="text-base/7 font-semibold text-gray-900">Opinion</h2>
        <p class="mt-1 text-sm/6 text-gray-600">
          Escriba su opinion para: <strong style="background-color: greenyellow">{{ NombreJuego }}</strong>
        </p>
        <br>
        <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
          <div class="sm:col-span-4">
            <h5
              for="username"
              class="block text-sm/3 font-medium text-gray-900"
              >Nombre de Usuario</h5
            >
            <div class="mt-2">
              <div
                class="flex rounded-md shadow-sm ring-1 ring-inset ring-gray-300 focus-within:ring-2 focus-within:ring-inset focus-within:ring-indigo-600 sm:max-w-md"
              >
                <span
                  >GamesOpinions.com/</span
                >
                <input
                  type="text"
                  name="username"
                  id="username"
                  autocomplete="username"
                  class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm/6"
                  placeholder="vivian"
                />
              </div>
            </div>
          </div>
          <br />
          <div class="col-span-full">
            <label for="about" class="block text-sm/6 font-medium text-gray-900"
              >Opinion del Juego:</label
            >
            <div class="mt-2">
              <textarea
                id="about"
                name="about"
                rows="5"
                class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm/6"
                placeholder="Escriba su opinion aquí"
                v-model="NuevaOpinion"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <br />
    <div class="mt-6 flex items-center justify-end gap-x-6">
      <b-button
        href="#"
        variant="secondary"
        @click="MostrarOpinion(NuevaOpinion)"
        >Actualizar</b-button
      >
    </div>
    <div v-if="opiniones.length > 0">
      <p class="mt-4 text-lg font-medium text-gray-900">
        <strong>Opinion</strong>
      </p>
      <ul class="list-disc list-inside text-gray-600">
        <p v-for="(opinion, index) in opiniones" :key="index">
          {{ opinion }}
        </p>
      </ul>
      <b-button
        class="mt-2 me-4"
        variant="danger"
        @click="EliminarOpinion(index)"
        >Eliminar</b-button
      >
      <b-button
        class="mt-2 me-4"
        variant="warning"
        @click="EditarOpinion(index)"
        >Editar</b-button
      >
    </div>
  </form>
</template>

<script>
import Vue from "vue";

export default Vue.extend({
  name: "FormOpinionView",
  props: ['NombreJuego'],
  data() {
    return {
      opiniones: [],
      NuevaOpinion: "",
    };
  },
  methods: {
    MostrarOpinion() {
      this.opiniones.push(this.NuevaOpinion);
      this.NuevaOpinion = "";
    },
    EditarOpinion(index) {
      this.opiniones.splice(index, 1);
    },
    EliminarOpinion() {
      this.opiniones.pop(this.NuevaOpinion);
    },
  },
});
</script>
