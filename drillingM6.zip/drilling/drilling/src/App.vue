<template>
  <div id="app">
    <nav>
      <NavbarComponent/>
    </nav>
    <router-view/>
  </div>
</template>
<script>
import NavbarComponent from './components/NavbarComponent.vue';
import Vue from 'vue';
export default Vue.extend({
  name:"App",
    components: {
      NavbarComponent,
    },
})
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

</style>
