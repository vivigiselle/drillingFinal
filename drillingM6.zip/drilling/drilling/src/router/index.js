import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AdmView from '@/views/AdmView.vue'
import FormOpinionView from '@/views/FormOpinionView.vue'
import AccountView from '@/views/AccountView.vue'
import PageError from '@/views/PageError.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/adm',
    name: 'adm',
    component: AdmView
  },
  {
    path: '/opinion/:NombreJuego',
    name: 'opinion',
    component: FormOpinionView,
    props: true
  },
  {
    path: '/account',
    name: 'account',
    component: AccountView
  },
  {
    path: '/error',
    name: 'error',
    component: PageError
  },
]


const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
