<template>
  <div>
    <b-navbar type="dark" variant="dark">
      <b-navbar-brand class="navbar-brand-left"
        ><b-icon icon="Controller" class="ms-3 me-2" variant="light"></b-icon
        >Games Opinions</b-navbar-brand
      >
      <b-navbar-nav class="navbar-nav-right">
        <b-nav-item>
          <router-link to="/" class="nav-link" id="home">
            <b-icon icon="house-door" variant="light" class="ms-3 me-2"></b-icon
            >Home</router-link
          >
        </b-nav-item>
      </b-navbar-nav>
    </b-navbar>
  </div>
</template>

<script>
import Vue from "vue";
import CardComponent from "./CardComponent.vue";
export default Vue.extend({
  name: "NavbarComponent",
  components: CardComponent,
});
</script>

<style scoped>
.navbar-brand-left {
  margin-right: auto;
}
.navbar-nav-right {
  margin-left: auto;
}
</style>
