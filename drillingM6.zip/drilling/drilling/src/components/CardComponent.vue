<template>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col ms-5 mb-3">
        <b-card img-alt="Image" img-top style="max-width: 20em" class="mb-3">
          <b-img
            :src="gameProps.background_image"
            alt="Game Image"
            width="286"
            height="161"
            class="card-img-top"
          >
          </b-img>
          <div>
            <h5 class="row justify-content-center m-2">
              {{ gameProps.name }}
            </h5>
          </div>
          <b-list-group
            >
            <h6>
              <b-list-group-item
                >Rating: {{ gameProps.rating }}</b-list-group-item
              >
              <b-list-group-item
                >Releasad: {{ gameProps.released }}</b-list-group-item
              >
              <b-list-group-item
                >Update:{{ gameProps.updated }}</b-list-group-item
              >
            </h6></b-list-group
          >
          <b-button variant="primary"  @click="OpinionJuego">Opinion</b-button>
          <button class="btnheart" @click="$router.push('/adm')">
            <svg
              class="icon"
              xmlns="http://www.w3.org/2000/svg"
              width="20.503"
              height="20.625"
              viewBox="0 0 17.503 15.625"
            >
              <path
                id="Fill"
                d="M8.752,15.625h0L1.383,8.162a4.824,4.824,0,0,1,0-6.762,4.679,4.679,0,0,1,6.674,0l.694.7.694-.7a4.678,4.678,0,0,1,6.675,0,4.825,4.825,0,0,1,0,6.762L8.752,15.624ZM4.72,1.25A3.442,3.442,0,0,0,2.277,2.275a3.562,3.562,0,0,0,0,5l6.475,6.556,6.475-6.556a3.563,3.563,0,0,0,0-5A3.443,3.443,0,0,0,12.786,1.25h-.01a3.415,3.415,0,0,0-2.443,1.038L8.752,3.9,7.164,2.275A3.442,3.442,0,0,0,4.72,1.25Z"
                transform="translate(0 0)"
              ></path>
            </svg>
          </button>
        </b-card>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
export default Vue.extend({
  name: "CardComponent",
  props: {
    gameProps: {
      type: Object,
      required: true,
    },
  },
  methods: {
    OpinionJuego() {
      this.$router.push({
        name: "opinion",
        params: { NombreJuego: this.gameProps.name },
      });
    },
  },
});
</script>

<style>
.btnheart {
  align-items: center;
  justify-content: center;
  width: 50px;
  height: 50px;
  border-radius: 10px;
  cursor: pointer;
  border: none;
  background-color: transparent;
  position: relative;
}
.btnheart::after {
  content: "like";
  width: fit-content;
  height: fit-content;
  position: absolute;
  font-size: 15px;
  color: white;
  font-family: "Lucida Sans", "Lucida Sans Regular", "Lucida Grande",
    "Lucida Sans Unicode", Geneva, Verdana, sans-serif;
  opacity: 0;
  visibility: hidden;
  transition: 0.2s linear;
  top: 115%;
}

.icon {
  width: 25px;
  height: 25px;
  transition: 0.2s linear;
}

.icon path {
  fill: black;
  transition: 0.2s linear;
}

.btnheart:hover > .icon {
  transform: scale(1.2);
}

.btnheart:hover > .icon path {
  fill: rgb(182, 30, 30);
}

.btnheart:hover::after {
  visibility: visible;
  opacity: 1;
  top: 105%;
}
</style>
