
function ocultar(){
    document.getElementById ("#boton");
    boton.style.display="none";
    formulario.style.display="block"

}

function mostrar(){
    document.getElementById ("#formulario");
    formulario.style.display="none";
    boton.style.display="block";
}


document.getElementById("#boton").addEventListener('mouseover', function() {
    this.classList.add('cursor-pointer');
})

document.getElementById("#boton").addEventListener('mouseout', function() {
    this.classList.remove('cursor-pointer');
})