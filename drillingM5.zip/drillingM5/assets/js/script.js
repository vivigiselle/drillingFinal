const seccion = document.getElementById("seccion1");
const seccion2 = document.getElementById("seccion2");
const seccion3 = document.getElementById("seccion3");
const personajes = document.getElementById("personajes1");
const personajes2 = document.getElementById("personajes2");
const personajes3 = document.getElementById("personajes3");

seccion.addEventListener("click", function () {
    if (seccion) {
        const DatosPersonajes = async () => {
            for (let i = 1; i < 5; i++) {
                try {
                    let response = await fetch(`https://swapi.dev/api/people/${i}/?format=json`);
                    let datos = await response.json();
                    personajes.innerHTML += `
                        <div>
                            <div class="single-timeline-content d-flex wow fadeInLeft" data-wow-delay="0.3s"
                            style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInLeft;">
                                <div class="timeline-icon color-icon1"></div>
                                <div class="timeline-text">
                                    <h6>${datos.name}</h6>
                                    <p>Altura: ${datos.height}cm Peso: ${datos.mass} Kg</p>
                                </div>
                            </div>
                         </div>   
                    `;
                } catch (error) {
                    console.error("No existe el personaje", error);
                }
            }
        };
        DatosPersonajes();
    }
});

seccion2.addEventListener("click", function () {
    if (seccion2) {
        const DatosPersonajes = async () => {
            for (let i = 6; i < 10; i++) {
                try {
                    let response = await fetch(`https://swapi.dev/api/people/${i}/?format=json`);
                    let datos = await response.json();
                    personajes2.innerHTML += `
                        <div>
                            <div class="single-timeline-content d-flex wow fadeInLeft" data-wow-delay="0.3s"
                            style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInLeft;">
                                <div class="timeline-icon color-icon2"></div>
                                <div class="timeline-text">
                                    <h6>${datos.name}</h6>
                                    <p>Altura: ${datos.height}cm Peso: ${datos.mass} Kg</p>
                                </div>
                            </div>
                         </div>                     
                    `;
                } catch (error) {
                    console.error("No existe el personaje", error);
                }
            }
        };

        DatosPersonajes();
    }
});

seccion3.addEventListener("click", function () {
    if (seccion3) {
        const DatosPersonajes = async () => {
            for (let i = 11; i < 15; i++) {
                try {
                    let response = await fetch(`https://swapi.dev/api/people/${i}/?format=json`);
                    let datos = await response.json();
                    personajes3.innerHTML += `
                        <div>
                            <div class="single-timeline-content d-flex wow fadeInLeft" data-wow-delay="0.3s"
                            style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInLeft;">
                                <div class="timeline-icon color-icon3"></div>
                                <div class="timeline-text">
                                    <h6>${datos.name}</h6>
                                    <p>Altura: ${datos.height}cm Peso: ${datos.mass} Kg</p>
                                </div>
                            </div>
                         </div>                    
                    `;
                } catch (error) {
                    console.error("No existe el personaje", error);
                }
            }
        };

        DatosPersonajes();
    }
});

