let detalle = document.getElementById ("detalle");

class Producto {
    constructor (nombre, precio, cantidad){
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
}

class Carrito {
    constructor(){
        this.productos = [];
    }
    
    agregarProducto(producto) {
            let existe = this.productos.find(item => {
               return item.nombre == producto.nombre
            })
            if(existe != undefined) {
                existe.cantidad += 1;
            }else {
                producto.cantidad = 1;
                this.productos.push(producto);
            }
            console.log(this.productos);
            alert(producto.nombre + " de $" + producto.precio + " ha sido añadido al carrito.");
            this.sumaraCarrito();
            this.calcularTotal();
        }
        
    sumaraCarrito() {
            let cantidadCarrito = document.getElementById("carrito");
            let totalProductos = this.productos.reduce((acumulador, producto) => acumulador + producto.cantidad, 0);
            cantidadCarrito.innerText = totalProductos;
    }

    calcularTotal(){
        let total = this.productos.reduce((acumulador, producto) => acumulador + (producto.cantidad * producto.precio), 0);
        document.getElementById("total").innerHTML = total;
    }   
}

let productos = {
    'avena' : new Producto ("Leche de Avena", 3200),
    'almendras' : new Producto ("Leche de Almendras", 1600),
    'molde' : new Producto ("Pan de Molde", 2500),
    'ciabatta' : new Producto ("Pan Ciabatta", 1500),
    'mantecoso' : new Producto ("Queso Mantecoso", 5000),
    'parmesano' : new Producto ("Queso Parmesano", 1000),
    'granulado' : new Producto ("Queso Vegano Granulado", 4000),
    'mermelada' : new Producto ("Mermelada", 1100),
    'azucar' : new Producto ("Azucar", 1400),
    'stevia' : new Producto ("Estevia", 3500),
};

let compra = new Carrito();


function agregarCarrito(nombre_producto) {
    let producto = productos[nombre_producto];
    if (producto) { 
        compra.agregarProducto(producto);
        compra.calcularTotal();
    }else {
        alert("Producto sin stock.");
    }
}



       


