# prueba_certificacion

# Proyecto Vue.js 2.0 con Vuetify y Lottie

Este proyecto es una aplicación Vue.js que utiliza Vuetify para el diseño de la interfaz de usuario y Lottie para animaciones.

## Requisitos

- Node.js
- Vue CLI

## Instalación

Sigue estos pasos para configurar el proyecto:

### 1. Clonar el repositorio

## Project setup
```
npm install
vue add vuetify
npm install lottie-web
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
