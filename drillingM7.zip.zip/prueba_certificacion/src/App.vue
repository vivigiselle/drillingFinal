<template>
  <v-app>
    <div id="app">
      <NavBarComponent />
      <HeaderComponent />
      <router-view />
      <FooterComponent />
    </div>
  </v-app>
</template>

<script>
import Vue from "vue";
import NavBarComponent from "./components/NavBarComponent.vue";
import FooterComponent from "./components/FooterComponent.vue";
import HeaderComponent from "./components/HeaderComponent.vue";
export default Vue.extend({
  name: "App",
  components: {
    NavBarComponent,
    FooterComponent,
    HeaderComponent,
  },

  data: () => ({
    //
  }),
});
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
}
</style>
