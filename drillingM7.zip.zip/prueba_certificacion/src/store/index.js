import Vue from 'vue'
import Vuex from 'vuex'
import APIPizzas from "@/views/APIPizzas";


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    //Aqui ira la API. Puedo pegarla completa o llamar al nombre de la variable de API.JS
    //agregro un arreglo para ver en carrito version miniatura o en otra vista ej: cart[]
    pizzas: APIPizzas.pizzas,
    cart:[],
  },
  getters: {
    //Para ver la cantidad que estoy agregando al carrito + precio
    cartTotal(state) {
      return state.cart.reduce((total, item) => total + item.price * item.quantity, 0);
    },
    //Para mi vista de pedido
    cardItem(state) {
      return state.cart.length
    }
  },
  mutations: {
    //mutacion de añadir
    ADD_TO_CART (state, pizza) {
    const existProduct = state.cart.find (item => item.id === pizza.id)
    if(!existProduct){
      state.cart.push ({...pizza, quantity: 1})
    } else{
    existProduct.quantity++
  } 
  },
    UPDATE_TO_CART (state,cargar) {
      const existProduct = state.cart.find ((item) => item.id === cargar.id);
    if(existProduct){
      existProduct.quantity = cargar.quantity 
    }
  },
    DELETE_FROM_CART (state,pizza) {
      const existIndex = state.cart.findIndex ((item) => item.id === pizza.id);
    if(existIndex){
      state.cart.splice(existIndex,1)
    }
  }
},
  actions: {
  },
  modules: {
  }
})
