<template>
  <v-container>
    <v-row>
      <v-col v-for="pizza in pizzas" :key="pizza.id" cols="12" md="4">
        <CardComponent :pizza="pizza" @show-detail="openModal" />
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
import Vue from "vue";
import CardComponent from "@/components/CardComponent.vue";
export default Vue.extend({
  name: "ProductsView",
  components: {
    CardComponent,
  },
  data() {
    return {
      selectPizza: null,
    };
  },
  methods: {
    openModal(pizza) {
      this.selectPizza = pizza;
    },
  },
  computed: {
    pizzas() {
      return this.$store.state.pizzas;
    },
  },
});
</script>
