<template>
  <v-container>
    <h2>Detalle del Pedido</h2>
    <v-simple-table>
      <thead>
        <tr>
          <th v-if="$store.getters.cartItem === 0" colspan="4">
            No tienes productos en tu pedido
          </th>
          <th class="text-left">Tipo</th>
          <th class="text-left">Nombre</th>
          <th class="text-left">Cantidad</th>
          <th class="text-left">Precio</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in $store.state.cart" :key="item.id">
          <td>
            <v-img
              height="50"
              :src="requirePathImg(item.name)"
              id="tamaño"
            ></v-img>
          </td>
          <td>{{ item.name }}</td>
          <td>
            <v-btn icon @click="decrementarQuantity(item.id)">
              <v-icon>mdi-minus</v-icon>
            </v-btn>
            <span>{{ item.quantity }}</span>
            <v-btn icon @click="incrementarQuantity(item.id)">
              <v-icon>mdi-plus</v-icon>
            </v-btn>
          </td>
          <td>$ {{ (item.price * item.quantity).toLocaleString() }}</td>
          <td>
            <v-btn
              class="ma-2"
              color="red darken-1"
              text
              @click="eliminarPizza(item.id)"
              >Eliminar</v-btn
            >
          </td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td>
            <strong>Total:</strong>$
            {{ $store.getters.cartTotal.toLocaleString() }}
          </td>
          <td><strong></strong></td>
        </tr>
      </tfoot>
    </v-simple-table>

    <v-btn
      class="ma-2"
      :loading="loading3"
      :disabled="loading3"
      color="success"
      @click="pagarCompra"
    >
      Pagar Compra
      <template v-slot:loader>
        <span>Pagando...</span>
      </template>
    </v-btn>

    <v-dialog v-model="confirmacion" max-width="500px">
      <v-card>
        <v-card-title class="headline">Confirmar Compra</v-card-title>
        <v-card-text>¿Deseas efectuar el pago?</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="confirmarCompra">Sí</v-btn>
          <v-btn color="red darken-1" text @click="confirmacion = false"
            >No</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import Vue from "vue";
export default Vue.extend({
  name: "CarritoProductsView",
  data() {
    return {
      loader: null,
      loading: false,
      loading3: false,
      confirmacion: false,
    };
  },
  methods: {
    pagarCompra() {
      this.confirmacion = true;
    },
    requirePathImg(pizzaTipo) {
      try {
        return require(`@/assets/img/pizzas/${pizzaTipo}.jpg`);
      } catch (error) {
        return "";
      }
    },
    confirmarCompra() {
      this.confirmacion = false;
      this.loader = "loading3";
      this.router.push("/");
    },
    incrementarQuantity(id) {
      const item = this.$store.state.cart.find((item) => item.id === id);
      if (item) {
        this.$store.commit("UPDATE_TO_CART", {
          id,
          quantity: item.quantity + 1,
        });
      }
    },
    decrementarQuantity(id) {
      const item = this.$store.state.cart.find((item) => item.id === id);
      if (item && item.quantity > 1) {
        this.$store.commit("UPDATE_TO_CART", {
          id,
          quantity: item.quantity - 1,
        });
      }
    },
    eliminarPizza(id) {
      this.$store.commit("DELETE_FROM_CART", id);
    },
  },
  watch: {
    loader() {
      const l = this.loader;
      this[l] = !this[l];

      setTimeout(() => (this[l] = false), 2000);

      this.loader = null;
    },
  },
});
</script>

<style>
.custom-loader {
  animation: loader 1s infinite;
  display: flex;
}
@-moz-keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
@-webkit-keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
@-o-keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
#tamaño {
  width: 50px;
  height: 50px;
  border-radius: 5px;
}
</style>
