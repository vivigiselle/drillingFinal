<template>
  <div align="center">
    <v-container class="ma-8">
      <h1>Lo sentimos, Página No Encontrada</h1>
      <AnimationNotFound />
    </v-container>
  </div>
</template>
<script>
import Vue from "vue";
import AnimationNotFound from "@/components/AnimationNotFound.vue";
export default Vue.extend({
  name: "NotFoundView",
  components: {
    AnimationNotFound,
  },
});
</script>
