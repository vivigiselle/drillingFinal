import Vue from "vue";
import VueRouter from "vue-router";
import ProductsView from "../views/ProductsView.vue";
import CarritoProductsView from "@/views/CarritoProductsView.vue";
import NotFoundView from "@/views/NotFoundView.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "ProductsView",
    component: ProductsView,
  },
  {
    path: "/carrito",
    name: "CarritoProductsView",
    component: CarritoProductsView,
  },
   {
     path: "*",
     name: "NotFound",
     component: NotFoundView,
   },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
