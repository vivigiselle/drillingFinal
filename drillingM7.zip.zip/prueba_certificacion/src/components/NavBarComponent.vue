<template>
  <div>
    <v-app-bar color="deep-orange accent-4" dense dark>
      <v-menu offset-y>
        <template v-slot:activator="{ on, attrs }">
          <v-btn text v-bind="attrs" v-on="on">
            <v-app-bar-nav-icon></v-app-bar-nav-icon>
          </v-btn>
        </template>
        <v-list>
          <v-list-item>
            <v-btn icon to="/">
              <v-icon>mdi-home</v-icon>
            </v-btn>
            Incio
          </v-list-item>
          <v-list-item>
            <v-list-item-title @click="$router.push('/carrito')"
              >Detalle de Compra</v-list-item-title
            >
          </v-list-item>
          <v-list-item>
            <v-list-item-title @click="$router.push('/notFound')"
              >Filtrar precios</v-list-item-title
            >
          </v-list-item>
        </v-list>
      </v-menu>
      <v-spacer></v-spacer>
      <v-text-field
        solo-inverted
        placeholder="Buscador"
        v-model="search"
        hide-details
        flat
        class="mx-auto"
        style="max-width: 200px"
      >
      </v-text-field>
      <router-link to="/search">
        <v-btn icon class="mx-2">
          <v-icon>mdi-magnify</v-icon>
        </v-btn>
      </router-link>
      <router-link to="/"> </router-link>
      <router-link to="/carrito">
        <v-btn icon>
          <v-icon>mdi-cart</v-icon>
          <span> {{ $store.getters.cartTotal.toLocaleString() }} </span>
        </v-btn>
      </router-link>
    </v-app-bar>
  </div>
</template>
<script>
import Vue from "vue";
export default Vue.extend({
  name: "NavbarComponent",
});
</script>

<style lang="scss" scoped>
.v-list-item:hover {
  cursor: pointer;
  background-color: rgba(255, 152, 0, 0.2);
}
.v-list-item:hover .v-icon {
  color: #ff9800;
}
</style>
