<template>
  <v-footer dark padless>
    <v-card class="flex" flat tile>
      <v-card-title class="deep-orange accent-4">
        <h6>
          <strong class="subheading"
            >Copyright © 2024 Vivian Roa Tapia 🍕
          </strong>
        </h6>
        <v-spacer></v-spacer>
        <h6>Términos y Condiciones | Seguridad y Privacidad</h6>
        <v-spacer></v-spacer>
        <v-btn v-for="icon in icons" :key="icon" class="mx-4" dark icon>
          <v-icon size="20px">
            {{ icon }}
          </v-icon>
        </v-btn>
      </v-card-title>
    </v-card>
  </v-footer>
</template>
<script>
import Vue from "vue";
export default Vue.extend({
  data: () => ({
    icons: ["mdi-facebook", "mdi-twitter", "mdi-linkedin", "mdi-instagram"],
  }),
});
</script>
