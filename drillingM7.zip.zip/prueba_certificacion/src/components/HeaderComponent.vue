<template>
    <v-app-bar color="orange" dense dark class="justify-center">
      <v-toolbar-title class="text-center 100">Pizzeria ¡Mamamia!</v-toolbar-title>
    </v-app-bar>
  </template>
  
  <script>
  import Vue from "vue"; 
  export default Vue.extend({
    name: "HeaderComponent",
  });
  </script>
  
  <style scoped>
  .v-toolbar-title {
    font-weight: bold;
  }
  .w-100 {
    width: 100%;
  }
  .text-center {
    text-align: center;
  }
  </style>