<template>
  <v-card :loading="loading" class="mx-auto my-12" max-width="374">
    <template v-slot:progress>
      <v-progress-linear
        color="deep-orange"
        height="10"
        indeterminate
      ></v-progress-linear>
    </template>
    <v-img height="150" :src="requirePathImg(pizza.name)"></v-img>
    <v-card-title>
      <strong>🍕 {{ pizza.name }}</strong>
    </v-card-title>
    <v-card-text>
      <v-row align-top="center" class="mx-0">
        <v-rating
          :value="4.5"
          color="amber"
          dense
          half-increments
          readonly
          size="14"
        ></v-rating>
        <div class="grey--text ms-4"></div>
      </v-row>
      <v-card-text >
        Ingredientes: {{ pizza.ingredients.join(", ") }}
      </v-card-text>
      <v-card-title>
        <strong>Precio: </strong>${{ pizza.price.toLocaleString() }}
      </v-card-title>
    </v-card-text>
    <v-divider class="mx-4"></v-divider>
    <v-card-actions>
      <v-btn color="blue" text @click="mostrarDetalle" class="mx-8">
        Ver más
      </v-btn>
      <v-spacer></v-spacer>
      <v-btn color="green" text @click="addToCart(pizza)" class="mx-4">
        Añadir
      </v-btn>
    </v-card-actions>
    <v-dialog v-model="showModal" max-width="500px">
      <v-card>
        <v-img :src="requirePathImg(pizza.name)"></v-img>
        <v-card-title>
          <strong>{{ pizza.name }}</strong>
        </v-card-title>
        <v-card-text>
          {{ pizza.desc }}
        </v-card-text>
        <ul>
          <li v-for="(ingredient, index) in pizza.ingredients" :key="index">
            {{ ingredient }}
          </li>
        </ul>
        <v-card-actions>
          <v-btn color="green darken-1" class="white--text" @click="addToCart(pizza)">
            Agregar: {{ pizza.price.toLocaleString() }}
          </v-btn>
          <v-btn color="red darken-1" class="white--text"  @click="ocultarModal">
            Cancelar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script>
import Vue from "vue";
export default Vue.extend({
  name: "CardComponent",
  props: {
    pizza: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      loading: false,
      showModal: false,
    };
  },
  methods: {
    requirePathImg(pizzaTipo) {
      try {
        return require(`@/assets/img/pizzas/${pizzaTipo}.jpg`);
      } catch (error) {
        return "";
      }
    },
    mostrarDetalle() {
      this.$emit("show-detail", this.pizza);
      this.showModal = true;
    },
    ocultarModal() {
      this.showModal = false;
    },
    addToCart(pizza) {
      this.loading = true;
      setTimeout(() => {
        this.loading = false;
        this.$store.commit("ADD_TO_CART", pizza);
      }, 1000);
    },
  },
});
</script>
