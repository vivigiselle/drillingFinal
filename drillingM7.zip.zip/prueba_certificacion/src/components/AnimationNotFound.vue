<template>
  <div ref="animationLottie" style="height: 500px; width: 500px"></div>
</template>

<script>
import Vue from "vue";
import lottie from "lottie-web";
import animationData from "@/assets/json/animation.json";
export default Vue.extend({
  name: "AnimationNotFound",
  mounted() {
    lottie.loadAnimation({
      container: this.$refs.animationLottie,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: animationData,
    });
  },
});
</script>
